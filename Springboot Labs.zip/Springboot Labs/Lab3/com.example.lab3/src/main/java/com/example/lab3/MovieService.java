package com.example.lab3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MovieService {
	@Autowired
	MovieRepository movieRepository;

	public List<Movie> getAllMovies() {
		List<Movie> movie=new ArrayList<Movie>();
		movieRepository.findAll().forEach(movie1->movie.add(movie1));
		return movie;
		
	}

	public void deleteMovie(String movieName) {
		movieRepository.deleteById(movieName);	
	}

	public List<Movie> getMovieByGenre(String genre) {
		List<Movie> movie=new ArrayList<Movie>();
		movieRepository.findAll().forEach(movie1->movie.add(movie1));
		List<Movie> genreBasedMovie=new ArrayList<Movie>();
		for(Movie m:movie)
		{
			if(m.getGenre().equals(genre))
				genreBasedMovie.add(m);	
		}
		return genreBasedMovie;
	}

	public void insertMovie(Movie movie) {
		movieRepository.save(movie);
	}

	public Movie updateMovie(Movie movie) {
		// TODO Auto-generated method stub
		return movieRepository.save(movie);
	}

}
